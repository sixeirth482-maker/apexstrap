# Apexstrap

Apexstrap is an independent Android Roblox launcher project based on the Chevstrap source code.

> This project is an unofficial third-party launcher. It is not affiliated with Roblox.

## Project status

**Stage 0 — Rebrand and build baseline**

- Project display name changed to Apexstrap.
- Gradle root project name changed to Apexstrap.
- Original Android package/namespace is intentionally unchanged for the first baseline build.
- Existing launcher functionality is preserved before feature development begins.
- Original license and attribution files are retained.

## Build

This project uses Gradle and Android tooling. To build a debug APK locally:

```bash
./gradlew :app:assembleDebug
```

Or run the **CI (Debug)** workflow from the GitHub Actions tab.

## Roadmap

1. Confirm the untouched baseline builds successfully.
2. Establish Apexstrap branding and a dark gaming visual direction.
3. Review the existing UI and settings architecture.
4. Add features in small, testable changes.

## Upstream and licensing

Apexstrap is derived from the Chevstrap source project. The upstream license and Bloxstrap license files are included in this repository. Preserve those notices and review their terms before distributing modified builds.

Do not assume every bundled asset or third-party dependency has the same license; check its individual terms before redistribution.
